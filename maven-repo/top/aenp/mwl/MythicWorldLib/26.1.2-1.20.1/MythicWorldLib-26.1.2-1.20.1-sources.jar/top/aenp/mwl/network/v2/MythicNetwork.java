package top.aenp.mwl.network.v2;

import io.netty.buffer.Unpooled;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2540;
import net.minecraft.class_2658;
import net.minecraft.class_2817;
import net.minecraft.class_2899;
import net.minecraft.class_2913;
import net.minecraft.class_2960;
import top.aenp.mwl.MythicWorldLib;
import top.aenp.mwl.network.v2.interfaces.PacketCodec;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginC2SPayload;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginS2CPayload;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicPlayC2SPayload;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicPlayS2CPayload;

import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings({"unchecked", "unused"})
public class MythicNetwork {
    public static final MythicNetwork INSTANCE = new MythicNetwork();
    public static final int QUERY_ID = -2147483600;
    public static final String MOD_VERSION = FabricLoader.getInstance().getModContainer(MythicWorldLib.MOD_ID).orElseThrow().getMetadata().getVersion().getFriendlyString();

    public final ConcurrentHashMap<class_2960, PacketCodec<class_2540, ? extends MythicLoginS2CPayload>> LOGIN_S2C_CODECS = new ConcurrentHashMap<>();
    public final ConcurrentHashMap<class_2960, PacketCodec<class_2540, ? extends MythicLoginC2SPayload>> LOGIN_C2S_CODECS = new ConcurrentHashMap<>();

    public final ConcurrentHashMap<class_2960, PacketCodec<class_2540, ? extends MythicPlayS2CPayload>> PLAY_S2C_CODECS = new ConcurrentHashMap<>();
    public final ConcurrentHashMap<class_2960, PacketCodec<class_2540, ? extends MythicPlayC2SPayload>> PLAY_C2S_CODECS = new ConcurrentHashMap<>();

    private static final class_2960 DUMMY_LOGIN_S2C_ID = new class_2960("mwt", "login_s2c");
    public static final class_2960 MYTHIC_PLAY_S2C_ID = new class_2960("mwt", "play_s2c");
    public static final class_2960 MYTHIC_PLAY_C2S_ID = new class_2960("mwt", "play_c2s");


    public static class_2899 createLoginS2CPacket(MythicLoginS2CPayload payload) {
        class_2540 packetByteBuf = new class_2540(Unpooled.buffer());
        class_2960 mythicId = payload.mythicId();
        PacketCodec<class_2540, MythicLoginS2CPayload> codec = (PacketCodec<class_2540, MythicLoginS2CPayload>) MythicNetwork.INSTANCE.LOGIN_S2C_CODECS.get(mythicId);
        packetByteBuf.method_10812(mythicId);
        codec.encode(packetByteBuf, payload);
        return new class_2899(QUERY_ID, DUMMY_LOGIN_S2C_ID, packetByteBuf);
    }

    public static class_2913 createLoginS2CPacket(MythicLoginC2SPayload payload) {
        class_2540 packetByteBuf = new class_2540(Unpooled.buffer());
        class_2960 mythicId = payload.mythicId();
        PacketCodec<class_2540, MythicLoginC2SPayload> codec = (PacketCodec<class_2540, MythicLoginC2SPayload>) MythicNetwork.INSTANCE.LOGIN_C2S_CODECS.get(mythicId);
        packetByteBuf.method_10812(mythicId);
        codec.encode(packetByteBuf, payload);
        return new class_2913(QUERY_ID, packetByteBuf);
    }

    public static class_2658 createPlayS2CPacket(MythicPlayS2CPayload payload) {
        class_2540 packetByteBuf = new class_2540(Unpooled.buffer());
        class_2960 mythicId = payload.mythicId();
        PacketCodec<class_2540, MythicPlayS2CPayload> codec = (PacketCodec<class_2540, MythicPlayS2CPayload>) MythicNetwork.INSTANCE.PLAY_S2C_CODECS.get(mythicId);
        packetByteBuf.method_10812(mythicId);
        codec.encode(packetByteBuf, payload);
        return new class_2658(MYTHIC_PLAY_S2C_ID, packetByteBuf);
    }

    public static class_2817 createPlayC2SPacket(MythicPlayC2SPayload payload) {
        class_2540 packetByteBuf = new class_2540(Unpooled.buffer());
        class_2960 mythicId = payload.mythicId();
        PacketCodec<class_2540, MythicPlayC2SPayload> codec = (PacketCodec<class_2540, MythicPlayC2SPayload>) MythicNetwork.INSTANCE.PLAY_C2S_CODECS.get(mythicId);
        packetByteBuf.method_10812(mythicId);
        codec.encode(packetByteBuf, payload);
        return new class_2817(MYTHIC_PLAY_S2C_ID, packetByteBuf);
    }
}
