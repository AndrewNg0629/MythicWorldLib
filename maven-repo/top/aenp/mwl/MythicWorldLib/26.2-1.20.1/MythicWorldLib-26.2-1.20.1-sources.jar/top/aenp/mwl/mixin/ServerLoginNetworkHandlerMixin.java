package top.aenp.mwl.mixin;

import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2913;
import net.minecraft.class_2960;
import net.minecraft.class_3248;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.interfaces.MythicServerLoginNetworkHandler;
import top.aenp.mwl.network.v2.interfaces.PacketCodec;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginC2SPayload;

@Mixin(value = class_3248.class, priority = 990)
public abstract class ServerLoginNetworkHandlerMixin {
    @Shadow
    public abstract void disconnect(class_2561 reason);

    @Inject(method = "onQueryResponse", at = @At(value = "HEAD"), cancellable = true)
    private void handleResponse(class_2913 packet, CallbackInfo info) {
        if (packet.method_36178() == MythicNetwork.QUERY_ID) {
            class_2540 packetByteBuf = packet.method_36179();
            if (packetByteBuf != null) {
                class_2960 mythicId = packetByteBuf.method_10810();
                PacketCodec<class_2540, ? extends MythicLoginC2SPayload> codec = MythicNetwork.INSTANCE.LOGIN_C2S_CODECS.get(mythicId);
                MythicLoginC2SPayload payload = codec.decode(packetByteBuf);
                payload.handle((MythicServerLoginNetworkHandler) this);
            } else {
                disconnect(class_2561.method_30163(String.format("Please have MythicWorldLib %s installed.", MythicNetwork.MOD_VERSION)));
            }
            info.cancel();
        }
    }
}
