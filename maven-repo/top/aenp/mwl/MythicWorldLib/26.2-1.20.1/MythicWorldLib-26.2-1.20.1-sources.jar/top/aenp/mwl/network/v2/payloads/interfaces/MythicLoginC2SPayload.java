package top.aenp.mwl.network.v2.payloads.interfaces;

import net.minecraft.class_2960;
import top.aenp.mwl.network.v2.interfaces.MythicServerLoginNetworkHandler;

public interface MythicLoginC2SPayload {
    class_2960 mythicId();

    void handle(MythicServerLoginNetworkHandler handler);
}
