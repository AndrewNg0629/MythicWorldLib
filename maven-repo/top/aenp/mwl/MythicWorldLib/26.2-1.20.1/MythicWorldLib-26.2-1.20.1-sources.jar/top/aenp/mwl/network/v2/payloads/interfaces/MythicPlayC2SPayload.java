package top.aenp.mwl.network.v2.payloads.interfaces;

import net.minecraft.class_2960;
import top.aenp.mwl.network.v2.interfaces.MythicServerPlayNetworkHandler;

public interface MythicPlayC2SPayload {
    class_2960 mythicId();
    void handle(MythicServerPlayNetworkHandler handler);
}
