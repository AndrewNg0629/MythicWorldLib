package top.aenp.mwl.mixin;

import io.netty.channel.Channel;
import net.minecraft.class_2535;
import net.minecraft.class_2539;
import net.minecraft.class_2596;
import net.minecraft.class_2899;
import net.minecraft.class_7648;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.aenp.mwl.network.v2.MythicNetwork;

@Mixin(value = class_2535.class, priority = 990)
public abstract class ClientConnectionMixin {

    @Shadow
    private int packetsSentCounter;

    @Shadow
    protected abstract class_2539 getState();

    @Shadow
    private Channel channel;

    @Shadow
    protected abstract void sendInternal(class_2596<?> packet, @Nullable class_7648 callbacks, class_2539 packetState, class_2539 currentState);

    @SuppressWarnings("resource")
    @Inject(method = "sendImmediately", at = @At(value = "HEAD"), cancellable = true)
    private void sendImmediately(class_2596<?> packet, @Nullable class_7648 callbacks, CallbackInfo info) {
        if (packet instanceof class_2899 queryPacket) {
            if (queryPacket.method_12592() == MythicNetwork.QUERY_ID) {
                class_2539 networkState = class_2539.method_10786(packet);
                class_2539 networkState2 = getState();
                packetsSentCounter++;
                if (networkState2 != networkState) {
                    if (networkState == null) {
                        throw new IllegalStateException("Encountered packet without set protocol: " + packet);
                    }
                    channel.config().setAutoRead(false);
                }
                if (channel.eventLoop().inEventLoop()) {
                    sendInternal(packet, callbacks, networkState, networkState2);
                } else {
                    channel.eventLoop().execute(() -> sendInternal(packet, callbacks, networkState, networkState2));
                }
                info.cancel();
            }
        }
    }
}
