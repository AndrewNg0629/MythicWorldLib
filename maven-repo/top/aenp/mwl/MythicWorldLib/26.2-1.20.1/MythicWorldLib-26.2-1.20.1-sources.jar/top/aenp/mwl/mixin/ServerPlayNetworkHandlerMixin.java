package top.aenp.mwl.mixin;

import net.minecraft.class_2540;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.interfaces.MythicServerPlayNetworkHandler;
import top.aenp.mwl.network.v2.interfaces.PacketCodec;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicPlayC2SPayload;

@Mixin(value = class_3244.class, priority = 990)
public abstract class ServerPlayNetworkHandlerMixin {
    @Inject(method = "onCustomPayload", at = @At(value = "HEAD"), cancellable = true)
    private void handleMythicPayloads(class_2817 packet, CallbackInfo info) {
        class_2960 channelName = packet.method_36169();
        if (MythicNetwork.MYTHIC_PLAY_C2S_ID.equals(channelName)) {
            class_2540 packetByteBuf = packet.method_36170();
            class_2960 mythicId = packetByteBuf.method_10810();
            PacketCodec<class_2540, ? extends MythicPlayC2SPayload> codec = MythicNetwork.INSTANCE.PLAY_C2S_CODECS.get(mythicId);
            MythicPlayC2SPayload playC2SPayload = codec.decode(packetByteBuf);
            playC2SPayload.handle((MythicServerPlayNetworkHandler) this);
            info.cancel();
        }
    }
}
