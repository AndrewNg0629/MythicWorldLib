package top.aenp.mwl.network.v2.payloads.interfaces;

import net.minecraft.class_2960;
import top.aenp.mwl.network.v2.interfaces.MythicClientLoginNetworkHandler;

public interface MythicLoginS2CPayload {
    class_2960 mythicId();

    void handle(MythicClientLoginNetworkHandler handler);
}
