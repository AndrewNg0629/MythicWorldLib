package top.aenp.mwl.mixin.client;

import net.minecraft.class_2540;
import net.minecraft.class_2899;
import net.minecraft.class_2960;
import net.minecraft.class_635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.interfaces.MythicClientLoginNetworkHandler;
import top.aenp.mwl.network.v2.interfaces.PacketCodec;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginS2CPayload;

@Mixin(value = class_635.class, priority = 990)
public class ClientLoginNetworkHandlerMixin {
    @Inject(method = "onQueryRequest", at = @At(value = "HEAD"), cancellable = true)
    private void handleRequest(class_2899 packet, CallbackInfo info) {
        if (packet.method_12592() == MythicNetwork.QUERY_ID) {
            class_2540 packetByteBuf = packet.method_36177();
            class_2960 mythicId = packetByteBuf.method_10810();
            PacketCodec<class_2540, ? extends MythicLoginS2CPayload> codec= MythicNetwork.INSTANCE.LOGIN_S2C_CODECS.get(mythicId);
            MythicLoginS2CPayload payload = codec.decode(packetByteBuf);
            payload.handle((MythicClientLoginNetworkHandler) this);
            info.cancel();
        }
    }
}
