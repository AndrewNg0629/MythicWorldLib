package top.aenp.mwl.network.v2.payloads.interfaces;

import net.minecraft.class_2960;
import top.aenp.mwl.network.v2.interfaces.MythicClientPlayNetworkHandler;

public interface MythicPlayS2CPayload {
    class_2960 mythicId();
    void handle(MythicClientPlayNetworkHandler handler);
}
