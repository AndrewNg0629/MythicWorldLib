package top.aenp.mwl.mixin.client;

import net.minecraft.class_2540;
import net.minecraft.class_2600;
import net.minecraft.class_2602;
import net.minecraft.class_2658;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.interfaces.MythicClientPlayNetworkHandler;
import top.aenp.mwl.network.v2.interfaces.PacketCodec;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicPlayS2CPayload;

@Mixin(value = class_634.class, priority = 990)
public abstract class ClientPlayNetworkHandlerMixin {
    @Shadow
    @Final
    private class_310 client;

    @Inject(method = "onCustomPayload", at = @At(value = "HEAD"), cancellable = true)
    private void handleMythicPayload(class_2658 packet, CallbackInfo info) {
        class_2600.method_11074(packet, (class_2602) this, client);
        class_2960 channelName = packet.method_11456();
        if (MythicNetwork.MYTHIC_PLAY_S2C_ID.equals(channelName)) {
            class_2540 packetByteBuf = packet.method_11458();
            class_2960 mythicId = packetByteBuf.method_10810();
            PacketCodec<class_2540, ? extends MythicPlayS2CPayload> codec = MythicNetwork.INSTANCE.PLAY_S2C_CODECS.get(mythicId);
            MythicPlayS2CPayload payload = codec.decode(packetByteBuf);
            payload.handle((MythicClientPlayNetworkHandler) this);
            info.cancel();
        }
    }
}
