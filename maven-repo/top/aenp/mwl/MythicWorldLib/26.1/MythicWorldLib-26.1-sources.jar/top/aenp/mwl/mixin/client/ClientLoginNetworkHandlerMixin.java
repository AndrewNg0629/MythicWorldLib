package top.aenp.mwl.mixin.client;

import net.minecraft.class_2899;
import net.minecraft.class_635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.interfaces.MythicClientLoginNetworkHandler;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginS2CPayload;

@Mixin(value = class_635.class, priority = 990)
public class ClientLoginNetworkHandlerMixin {
    @Inject(method = "onQueryRequest", at = @At(value = "HEAD"), cancellable = true)
    private void handleRequest(class_2899 packet, CallbackInfo info) {
        if (packet.comp_1567() == MythicNetwork.QUERY_ID) {
            MythicLoginS2CPayload payload = (MythicLoginS2CPayload) packet.comp_1568();
            payload.handle((MythicClientLoginNetworkHandler) this);
            info.cancel();
        }
    }
}
