package top.aenp.mwl.network.v2.payloads.interfaces;

import net.minecraft.class_8710;
import top.aenp.mwl.network.v2.interfaces.MythicServerPlayNetworkHandler;

public interface MythicPlayC2SPayload extends class_8710 {
    void handle(MythicServerPlayNetworkHandler handler);
}
