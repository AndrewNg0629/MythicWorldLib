package top.aenp.mwl.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_2540;
import net.minecraft.class_2913;
import net.minecraft.class_2960;
import net.minecraft.class_8594;
import net.minecraft.class_9139;
import net.minecraft.class_9141;
import net.minecraft.class_9143;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import top.aenp.mwl.misc.MythicReflectionUtils;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginC2SPayload;

@Mixin(value = class_2913.class, priority = 990)
public class LoginQueryResponseC2SPacketMixin {
    @WrapOperation(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/packet/Packet;createCodec(Lnet/minecraft/network/codec/ValueFirstEncoder;Lnet/minecraft/network/codec/PacketDecoder;)Lnet/minecraft/network/codec/PacketCodec;"))
    private static class_9139<class_2540, class_2913> swapCodec(class_9143<class_2540, class_2913> encoder, class_9141<class_2540, class_2913> decoder, Operation<class_9139<class_2540, class_2913>> original) {
        return new class_9139<>() {
            @Override
            public class_2913 decode(class_2540 buf) {
                int queryId = buf.method_10816();
                class_8594 payload = null;
                if (queryId == MythicNetwork.QUERY_ID) {
                    if (buf.readBoolean()) {
                        class_2960 mythicType = buf.method_10810();
                        class_9139<class_2540, ? extends MythicLoginC2SPayload> codec = MythicNetwork.INSTANCE.LOGIN_C2S_CODECS.get(mythicType);
                        payload = codec != null ? codec.decode(buf) : null;
                    }
                } else {
                    payload = MythicReflectionUtils.LoginQueryResponseC2SPacket$readPayload(queryId, buf);
                }
                return new class_2913(queryId, payload);
            }

            @Override
            public void encode(class_2540 buf, class_2913 packet) {
                buf.method_10804(packet.comp_1569());
                buf.method_43826(packet.comp_1570(), (bufx, response) -> response.method_52295(bufx));
            }
        };
    }
}
