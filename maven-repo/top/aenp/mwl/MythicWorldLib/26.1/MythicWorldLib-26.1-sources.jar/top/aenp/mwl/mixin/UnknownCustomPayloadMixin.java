package top.aenp.mwl.mixin;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_8711;
import net.minecraft.class_9139;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import top.aenp.mwl.network.v2.MythicNetwork;

@Mixin(class_8711.class)
public class UnknownCustomPayloadMixin {
    @Inject(method = "createCodec", at = @At(value = "HEAD"), cancellable = true)
    private static void supplyMythicCodec(class_2960 id, int maxBytes, CallbackInfoReturnable<class_9139<class_2540, ? extends class_8710>> info) {
        class_9139<class_2540, ? extends class_8710> codec = MythicNetwork.INSTANCE.CUSTOM_PAYLOAD_CODECS.get(id);
        if (codec != null) {
            info.setReturnValue(codec);
        }
    }
}
