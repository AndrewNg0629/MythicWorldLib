package top.aenp.mwl.network.v2.payloads.interfaces;

import net.minecraft.class_8710;
import top.aenp.mwl.network.v2.interfaces.MythicClientPlayNetworkHandler;

public interface MythicPlayS2CPayload extends class_8710 {
    void handle(MythicClientPlayNetworkHandler handler);
}
