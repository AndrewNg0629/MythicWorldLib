package top.aenp.mwl.network.v2.payloads.interfaces;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8594;
import net.minecraft.class_9139;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.interfaces.MythicServerLoginNetworkHandler;

@SuppressWarnings("unchecked")
public interface MythicLoginC2SPayload extends class_8594 {
    @Override
    default void method_52295(class_2540 buf) {
        class_9139<class_2540, MythicLoginC2SPayload> codec = (class_9139<class_2540, MythicLoginC2SPayload>) MythicNetwork.INSTANCE.LOGIN_C2S_CODECS.get(mythicId());
        buf.method_10812(mythicId());
        codec.encode(buf, this);
    }

    class_2960 mythicId();

    void handle(MythicServerLoginNetworkHandler handler);
}
