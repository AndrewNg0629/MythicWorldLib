package top.aenp.mwl.mixin;

import net.minecraft.class_2535;
import net.minecraft.class_2817;
import net.minecraft.class_3244;
import net.minecraft.class_8609;
import net.minecraft.class_8710;
import net.minecraft.class_8792;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.aenp.mwl.network.v2.interfaces.MythicServerPlayNetworkHandler;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicPlayC2SPayload;

@Mixin(value = class_3244.class, priority = 990)
public abstract class ServerPlayNetworkHandlerMixin extends class_8609 {
    public ServerPlayNetworkHandlerMixin(MinecraftServer server, class_2535 connection, class_8792 clientData) {
        super(server, connection, clientData);
    }

    @Inject(method = "onCustomPayload", at = @At(value = "HEAD"), cancellable = true)
    private void handleMythicPayloads(class_2817 packet, CallbackInfo info) {
        class_8710 payload = packet.comp_1647();
        if (payload instanceof MythicPlayC2SPayload mythicPayload) {
            mythicPayload.handle((MythicServerPlayNetworkHandler) this);
            info.cancel();
        }
    }
}
