package top.aenp.mwl.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_2540;
import net.minecraft.class_2899;
import net.minecraft.class_2960;
import net.minecraft.class_8595;
import net.minecraft.class_9139;
import net.minecraft.class_9141;
import net.minecraft.class_9143;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import top.aenp.mwl.misc.MythicReflectionUtils;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginS2CPayload;

@Mixin(value = class_2899.class, priority = 990)
public class LoginQueryRequestS2CPacketMixin {
    @WrapOperation(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/packet/Packet;createCodec(Lnet/minecraft/network/codec/ValueFirstEncoder;Lnet/minecraft/network/codec/PacketDecoder;)Lnet/minecraft/network/codec/PacketCodec;"))
    private static class_9139<class_2540, class_2899> swapCodec(class_9143<class_2540, class_2899> encoder, class_9141<class_2540, class_2899> decoder, Operation<class_9139<class_2540, class_2899>> original) {
        return new class_9139<>() {
            @Override
            public class_2899 decode(class_2540 buf) {
                int queryId = buf.method_10816();
                class_8595 payload;
                if (queryId == MythicNetwork.QUERY_ID) {
                    buf.method_10810(); // Skip vanilla Identifier.
                    class_2960 mythicType = buf.method_10810();
                    class_9139<class_2540, ? extends MythicLoginS2CPayload> codec = MythicNetwork.INSTANCE.LOGIN_S2C_CODECS.get(mythicType);
                    payload = codec != null ? codec.decode(buf) : null;
                } else {
                    payload = MythicReflectionUtils.LoginQueryRequestS2CPacket$readPayload(buf.method_10810(), buf);
                }
                return new class_2899(queryId, payload);
            }

            @Override
            public void encode(class_2540 buf, class_2899 packet) {
                buf.method_10804(packet.comp_1567());
                buf.method_10812(packet.comp_1568().comp_1571());
                packet.comp_1568().method_52296(buf);
            }
        };
    }
}
