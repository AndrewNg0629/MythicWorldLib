package top.aenp.mwl.network.v2;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import top.aenp.mwl.MythicWorldLib;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginC2SPayload;
import top.aenp.mwl.network.v2.payloads.interfaces.MythicLoginS2CPayload;

import java.util.concurrent.ConcurrentHashMap;

public class MythicNetwork {
    public static final MythicNetwork INSTANCE = new MythicNetwork();
    public static final int QUERY_ID = -2147483600;
    public static final String MOD_VERSION = FabricLoader.getInstance().getModContainer(MythicWorldLib.MOD_ID).orElseThrow().getMetadata().getVersion().getFriendlyString();

    public final ConcurrentHashMap<class_2960, class_9139<class_2540, ? extends MythicLoginS2CPayload>> LOGIN_S2C_CODECS = new ConcurrentHashMap<>();
    public final ConcurrentHashMap<class_2960, class_9139<class_2540, ? extends MythicLoginC2SPayload>> LOGIN_C2S_CODECS = new ConcurrentHashMap<>();
    public final ConcurrentHashMap<class_2960, class_9139<class_2540, ? extends class_8710>> CUSTOM_PAYLOAD_CODECS = new ConcurrentHashMap<>();
}
