package top.aenp.mwl.network.v2.payloads.interfaces;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8595;
import net.minecraft.class_9139;
import top.aenp.mwl.network.v2.MythicNetwork;
import top.aenp.mwl.network.v2.interfaces.MythicClientLoginNetworkHandler;

@SuppressWarnings("unchecked")
public interface MythicLoginS2CPayload extends class_8595 {
    @Override
    default class_2960 comp_1571() {
        return class_2960.method_60655("mwt", "login_s2c_common"); //No use.
    }

    @Override
    default void method_52296(class_2540 buf) {
        class_9139<class_2540, MythicLoginS2CPayload> codec = (class_9139<class_2540, MythicLoginS2CPayload>) MythicNetwork.INSTANCE.LOGIN_S2C_CODECS.get(mythicId());
        buf.method_10812(mythicId());
        codec.encode(buf, this);
    }

    class_2960 mythicId();

    void handle(MythicClientLoginNetworkHandler handler);
}
