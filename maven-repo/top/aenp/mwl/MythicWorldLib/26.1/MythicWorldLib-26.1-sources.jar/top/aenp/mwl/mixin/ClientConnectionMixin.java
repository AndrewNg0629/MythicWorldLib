package top.aenp.mwl.mixin;

import io.netty.channel.Channel;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2899;
import net.minecraft.class_7648;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import top.aenp.mwl.network.v2.MythicNetwork;

@Mixin(value = class_2535.class, priority = 990)
public abstract class ClientConnectionMixin {
    @Shadow
    private int packetsSentCounter;

    @Shadow
    private Channel channel;

    @Shadow
    protected abstract void sendInternal(class_2596<?> packet, @Nullable class_7648 callbacks, boolean flush);

    @SuppressWarnings("resource")
    @Inject(method = "sendImmediately", at = @At(value = "HEAD"), cancellable = true)
    private void sendImmediately(class_2596<?> packet, @Nullable class_7648 callbacks, boolean flush, CallbackInfo info) {
        if (packet instanceof class_2899 queryPacket) {
            if (queryPacket.comp_1567() == MythicNetwork.QUERY_ID) {
                packetsSentCounter++;
                if (channel.eventLoop().inEventLoop()) {
                    sendInternal(packet, callbacks, flush);
                } else {
                    channel.eventLoop().execute(() -> sendInternal(packet, callbacks, flush));
                }
                info.cancel();
            }
        }
    }
}
